#!/bin/ash
while true; do echo "hello world"; sleep 2; done
