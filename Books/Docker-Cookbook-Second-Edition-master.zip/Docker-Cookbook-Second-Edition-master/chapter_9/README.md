# Chapter 9

In this chapter there isn't really any code, it is mostly shell commands. They are all listed by section, with any comments that should make things a little more clear, when needed.
